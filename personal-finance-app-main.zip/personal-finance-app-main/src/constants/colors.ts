export const COLOR_SUCCESS = "#0b8030"
export const COLOR_DANGER = "#d44"