export interface IconProps {
    setIcon: (icon: string) => void;
    selectedIcon?: string;
}