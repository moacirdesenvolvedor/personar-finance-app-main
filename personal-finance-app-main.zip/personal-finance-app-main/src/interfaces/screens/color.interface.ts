export interface ColorProps {
    setColor: (color: string) => void;
    selectedColor?: string;
}