export interface CategoriesList {
    icon: (size: number) => JSX.Element;
    label: string;
    background: string;
}