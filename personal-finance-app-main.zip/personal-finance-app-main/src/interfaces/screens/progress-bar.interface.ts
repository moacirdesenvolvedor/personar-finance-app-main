export interface ProgressBarProps {
    backColor: string;
    barColor: string;
    barText?: string;
    progress: number;
}