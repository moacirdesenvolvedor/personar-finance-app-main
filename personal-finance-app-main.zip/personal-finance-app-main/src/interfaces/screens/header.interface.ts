export interface HeaderStackProps {
    title: string;
    onRequestClose: () => void;
}