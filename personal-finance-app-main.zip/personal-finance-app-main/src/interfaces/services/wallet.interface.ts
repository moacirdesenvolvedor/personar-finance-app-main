export interface WalletDto {
    name: string;
}
export interface WalletEntity extends WalletDto {
    id: number;
}